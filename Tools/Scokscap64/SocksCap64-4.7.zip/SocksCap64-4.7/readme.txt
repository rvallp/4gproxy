﻿Sockscap64 - Makes Programs Support Socks Proxy

64 bit SocksCap, fully support Win XP/ Vista /Win7/ Win8 /Win 8.1/Win10 32 bit & 64 bit system.

SocksCap64 is a freeware developed by Taro that is an easy and a beautiful way to let the programs you want to work through a specific SOCKS proxy server, even if your applications don't have such an option. It allows you to use different proxies for different programs and make a launch list for the applications you wish to have a peculiar connection. SocksCap64 does not require modifications to the Winsock applications or the Winsock stacks.

With SocksCap64 you can work with any Internet client through a network that is separated from the Internet by a firewall (only one open port is required).


Here are some of its benefits:

Makes programs to work through a specific SOCKS proxy server;
Hides your activity and your IP address;
Manages proxies for each application;
Easy, simple, but very useful application;
Support Win XP/Win Vista/Win7/Win8/Win8.1/Win 10 32bit & 64bit system.
Support Socks4/4a/5/http/shadowsocks proxy protocols.
Support TCP/UDP network protocols.
Unlimited proxies.
Disable Temporarily.
100% free to download and 100% free to use.

SocksCap64 gets access through SOCKS4 and SOCKS5 proxies for almost every application. You don’t have to maintain any options in the program you want to work via proxy – SocksCap does everything itself.

keywords: bypass firewall, sockscap64, SocksCap 64 bit, SocksCap x64, Socks5 Proxy, Socks Tunnel

Taro labs is a laboratory founded by taro to develop free SOCKS tunnel software.

official website: https://www.sockscap64.com

About how to integrate sockscap64 with your program,please check file “Integration instructions.txt”
关于如何整合sockscap64，请查看“整合说明.txt”

Changelog:
========================================================================
2017-01-19 3.9
1, 解决一个运行时可能会导至的的重要错误, 强烈建议升级.
2, 解决某些采用UDP协议且使用了完成端口的程序无法正常运行的问题. ( 如: teamspeak )

2017-01-18 3.8
1, 加入繁体中文语言. 感谢网友Tinchbear辛勤付出,Twitter: @tinchbear
2, 加入系统代理(IE代理)功能.
3, 加入将快捷方式拉入SC64时自动导入快捷方式的参数信息.
4, 修正代理管理中当前活动代理图标显示偶尔异常的BUG.
5, 修正SS节点测试时总显示1ms的问题.
6, 解决如果当前代理不支持UDP从而导至某些使用UDP协议的软件无响应的问题.
7, 解决显示当前隧道中的程序无法显示64位程序的问题.
8, 增强JSON解析的兼容性. 能解析某些错误的JSON格式.
9, 退出程序时自动关闭代理功能.

2016-11-01 3.6
1, 修正通过命令行方式启动时会弹出之前启动进程SC主窗体的BUG.

2016-10-16 3.5
1, 重要安全更新,请务必更新到此版本!!!!!!
2, 加入Attach to process功能. ( 某些程序无法代理子进程,可以使用此功能来代理子进程 )

2016-09-28 3.3
1, ss新增支持Chacha20-ietf加密方式
2, 支持添加重复的EXE程序文件
2, 其它一些小BUG

2016-04-03 3.2
1, 应网友要求: 添加命令行参数--hideicon 隐藏托盘图标
2, 解决通过JSON格式添加SS节点导至程序出错的问题.

2016-03-18 3.1
1, 加入代理备注功能.
2, 支持通过未经BASE64的SS加接加入节点.
3, 优化UDP传输.
4, 优化代理测试,代理测试更快速.
5, 改进SS出错重连机制.
6, 改进SS代理 JSON格式, 兼容其它客户端版本.
7, 解决在最新的SS 服务器端LIBEV版本连接异常的问题.
8, 解决高DPI下界面图标错位的问题.
9, 解决SS节点密码中含有@字符无法通过SS,JSON,二维码加入的问题.
10, 修改可能存在无法提升新版本的问题.

2016.01-18 3.0
1, 修复在Http代理协议及Shadowsocks代理协议中的几个BUG.

2016.01-12 2.9
1, 修复一个可能会导至程序在启动崩溃的严重BUG.

2016-01-08 2.8
1, 支持Shadowsocks代理, HTTP代理.
2  增加-esilent, -quit两个参数 用于安静启动 以及退出以前启动的进程.
3, 当设置了系统代理时提醒用户.
4, 修正BUG: 修正多运行多个SocksCap64实例的时的检测功能的BUG.
5, 修正BUG: 显示界面的情况下,按win + d 显示桌面, 再点系统伴图标, 无法显示出主界面.
6, 修正BUG: PUTTY及MSTSC无法支持10.0.0.X段IP
7  修正BUG: 代理管理器中测试所有代理时'stop testing' 按扭也变得不可用了.
8  修正BUG: 启动微信PC客户端时出错.
9 修正BUG: 如果在主界面测试代理,接着把主界面X掉了,那个测试代理的窗口还在.
10 修正BUG: 代理密码为空的话, 验证失败.
11 修正BUG: 修正SOCKS4协议中的一点小BUG
12 修正BUG: 在XP下,NS有时会导至SC64出错
13 修正BUG: 些情况下UDP无法发送数据的BUG.

2015-06-27 2.6
========================================================================
1, 新功能: 可以显示当前通过代理的连接信息.
2, 新功能: 可以显示当前位于隧道中的程序.
3, 新功能: 为程序创建SC64快捷方式, 在桌面直接启动代理程序.
4, 新功能: 加入网络规则, 可以指定某些网站或者IP是否通过代理/直连/阻止.
5, 新功能: 创建SC64快捷方式. 之后可以通过SC64快捷方式直接启动程序进行代理而无需先启动SC64再启动程序.
6, 新功能: 安装向导多国语言支持.
7, 新功能: 界面操作方式调整. 主界面中可以直接测试代理及临时禁止SC64
8, 新特性: 修改DNS的解析方式, 使得整个程序运行更顺畅.
9, 新特性: 代理管理器中的代理密码显示为*(星号).
10, 修正BUG: 解决部份游戏和程序通过SocksCap64代理之后会产生界面卡顿问题.
12, 修正BUG: 帐号密码中含有特殊字符, 会使得客户端无法登录.
13, 修正BUG: 某些.NET程序无法被代理的问题.
14, 修正BUG: 退出SOCKSCAP64之后被代理的程序仍然可以连接网络.
15, 新功能: 代理管理器中可以删除当前活动代理.
16, 修正BUG: 代理管理器设置新的活动代理并立即删除它的话会出错.

2015-05-03 2.1
========================================================================
1, 修正BUG: 代理管理器中切换新的活动代理后无法再切换到之前的活动代理上.
2, 修正BUG: 代理管理器中IP地址输入一个域名的话会导至SOCKSCAP64出错.
3, 新功能:  代理地址可以是一个域名.
4, UDP协议的相关BUG
5, 去掉主界面底部的广告.

2015-04-15 2.0
========================================================================
1, 新功能: 加入支持UDP代理协议.
2, 新功能: 加入程序选择器功能. ( 添加程序时从程序选择器中选择本机已安装的程序进行代理 )
3, 新功能: 某些需要高权限才能运行的程序在SocksCap64中运行时给出提示.
4, 新功能: 代理管理器中加入'通过UDP协议测试代理'的功能.
5, 修正BUG: 偶然的情况下能启动进程,无法出现程序的界面.
6, 修正BUG: 在SocksCap64中选中某程序,点'运行'按扭不能运行.
7, 修正BUG: 被代理的程序正在运行中突然退出SocksCap64偶尔会导至SocksCap64出错. 
8, 修正BUG: 某些系统下重装SocksCap64时提示写入文件失败, 其实进程还在后台未退出.
9, 其它细节修改.

2015-03-23 1.2.1
========================================================================
1, 修正BUG: SocksCap64_RunAsAdmin无法运行.

2015-03-22 1.2
========================================================================
1, 加入新功能: 运行过程中可以随时切换当前使用的代理并立即生效.
2, 加入功能: 可以手动切换程序界面语言
3, 代理管理器功能增强, 测试代理时可以查看测试日志.
4, 启用了新的本地文件加密方式.
5, 系统栏系统中加入临时禁止SocksCap64功能.
6, 修改网站数据库版本发布表格结构.
7, 修改进程创建的方式. 某些特殊目录及文件结构的程序可能导至创建进程时出现误差.
8, 修改DLL的注入方式. 新的注入方式更稳定, 更能适应各程序的创建方式.
9, 修正在Windows 8系统下可能导至某些程序无法正常工作的问题.
10, 针对Wow魔兽世界做一系列优化修改.
11, 解决Wow魔兽世界登录战网提示: 您正在尝试登录一下无效的服务器.( You're trying to connect to an invalid server. )
12, 修正bug: 启动程序后按Win + D快捷键显示桌面后, 双击系统栏图标无法恢复显示程序.
13, 修改其它一些bug.



2015-02-13 1.0
========================================================================
1, 包含了”SocksCap”的功能, 并且完美支持XP/Vista/Win7/Win8 (32bit & 64bit).
2, 快速配置, 轻松上手. 可以自动导入系统中已经安装的Web Browser. 安装好Sockscap64之后几乎不再需要额外的工作就可以开始使用了.
3, 注册网站帐号并在Sockscap64登录之后, 能与网站集成, 网站购买或者申请试用的的Socks5代理可以直接更新至Sockscap64客户端使用.
4, 超好使用的代理管理器. 可同时加入无限数量的代理进行管理并灵活切换使用.
5, 您可以在使用中临时禁止Sockscap64的功能从而使用真实身份访问网络. ( 例如: 您当前能过Sockscap64访问网站显示你的IP来自某国代理, 临时禁止Sockscap64之后再刷新网站看到的就是你的真实IP身份).
6, 支持本地解析域名, 先本地再远程SOCKS代理解析, 直接通过远程SOCKS代理解析三种域名解析方式.
7, 完全按照RFC文档书写的Socks 4/5协议支持, 访问速度极快. 当前版本仅支持TCP连接, 后期版本中会加入UDP支持. 当前版本仅支持Socks 4/5协议.