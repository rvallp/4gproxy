using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace allproxyDllTest
{
    class Program
    {
        static void Main(string[] args)
        {

            var clientUniqueId = "abc123";
            var clientSessionId = "";

            Task.Factory.StartNew(() => {

                var session = AllproxyClient.Connect(
                       ToBytes("127.0.0.1:9082"),
                       ToBytes(""),
                       ToBytes(""),
                       true,
                       true,
                       ToBytes(clientUniqueId)
                    );

                clientSessionId = ToStr(session);
            });

            Task.Factory.StartNew(() =>
            {
                Thread.Sleep(3000);

                while (true)
                {
                    Thread.Sleep(1000);
                    var status = ToStr(AllproxyClient.GetConnStatus(ToBytes(clientSessionId)));
                    var connUrl = ToStr(AllproxyClient.GetPublicUrl(ToBytes(clientSessionId)));
                    Console.WriteLine("Status: {0}    Url: {1}",status,connUrl);
                }


            });

            Console.ReadLine();
        }

        public static string ToStr(IntPtr ptr)
        {
            if (ptr == IntPtr.Zero)
            {
                return null;
            }

            return Marshal.PtrToStringAnsi(ptr);
        }

        public static byte[] ToBytes(string v)
        {
            return Encoding.UTF8.GetBytes(v);
        }
    }
}
