using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;

namespace allproxyDllTest
{
    public static class AllproxyClient
    {
        [DllImport("allproxy.dll", EntryPoint = "Connect", CharSet = CharSet.Unicode, CallingConvention = CallingConvention.Cdecl)]
        public static extern IntPtr Connect(byte[] Connect, byte[] transferIP,byte[] realTrafficIp, bool enableHttp, bool enableSocks5, byte[] uniqueId);

        [DllImport("allproxy.dll", EntryPoint = "GetConnStatus", CharSet = CharSet.Unicode, CallingConvention = CallingConvention.Cdecl)]
        public static extern IntPtr GetConnStatus(byte[] uid);

        [DllImport("allproxy.dll", EntryPoint = "GetPublicUrl", CharSet = CharSet.Unicode, CallingConvention = CallingConvention.Cdecl)]
        public static extern IntPtr GetPublicUrl(byte[] uid);

       
    }
}
